export const DEFAULT_ASSUMPTIONS = Object.freeze({
  temperatureReferenceC: 18,
  temperatureToleranceC: 8,
  phReference: 7,
  phTolerance: 1.5,
  microplasticReferencePerL: 10,
  microplasticUpperReferencePerL: 100,
  weights: Object.freeze({ temperature: 0.2, ph: 0.2, microplastics: 0.4, waterQuality: 0.2 }),
  optionalWeight: 0.15,
  categoryBands: Object.freeze({ lowMax: 32, mediumMax: 65 }),
});

const WATER_QUALITY_SCORES = Object.freeze({ good: 10, moderate: 55, poor: 90 });
export const WATER_SOURCES = Object.freeze([
  'tap',
  'bottled',
  'treated',
  'lake',
  'rainwater',
  'river',
  'wastewater',
]);
const WATER_SOURCE_LABELS = Object.freeze({ tap: 'içme suyu (şebeke)', bottled: 'şişe suyu', treated: 'arıtılmış su', lake: 'göl suyu (durgun)', rainwater: 'yağmur suyu', river: 'nehir suyu', wastewater: 'atık su (arıtma öncesi)' });

const clamp = (value, min = 0, max = 100) => Math.max(min, Math.min(max, value));
const round = (value) => Math.round(value * 10) / 10;

export function validateMeasurements(input) {
  const errors = {};
  const requiredText = [
    ['sampleName', 'Analiz adı zorunludur.'],
    ['measuredAt', 'Ölçüm tarihi zorunludur.'],
    ['location', 'Konum / istasyon zorunludur.'],
    ['waterSource', 'Su türü seçilmelidir.'],
    ['waterQuality', 'Su kalitesi seçilmelidir.'],
  ];
  requiredText.forEach(([key, message]) => {
    if (!String(input[key] ?? '').trim()) errors[key] = message;
  });
  const numeric = [
    ['temperatureC', -50, 70, 'Sıcaklık -50 ile 70 °C arasında olmalıdır.'],
    ['ph', 0, 14, 'pH 0 ile 14 arasında olmalıdır.'],
    ['microplasticsPerL', 0, 1_000_000_000, 'Mikroplastik yoğunluğu 0 veya daha büyük olmalıdır.'],
    ['turbidityNtu', 0, 10_000, 'Bulanıklık 0 ile 10.000 NTU arasında olmalıdır.'],
    ['conductivityUs', 0, 200_000, 'İletkenlik 0 ile 200.000 µS/cm arasında olmalıdır.'],
    ['dissolvedOxygenMgL', 0, 30, 'Çözünmüş oksijen 0 ile 30 mg/L arasında olmalıdır.'],
    ['rainfallMm', 0, 5_000, 'Yağış 0 ile 5.000 mm arasında olmalıdır.'],
    ['uvIndex', 0, 20, 'UV indeksi 0 ile 20 arasında olmalıdır.'],
  ];
  numeric.forEach(([key, min, max, message]) => {
    const value = input[key];
    if (value === '' || value === null || value === undefined) {
      if (['temperatureC', 'ph', 'microplasticsPerL'].includes(key)) errors[key] = 'Bu ölçüm zorunludur.';
      return;
    }
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < min || parsed > max) errors[key] = message;
  });
  if (input.waterQuality && !Object.hasOwn(WATER_QUALITY_SCORES, input.waterQuality)) errors.waterQuality = 'Geçerli bir su kalitesi seçin.';
  if (input.waterSource && !WATER_SOURCES.includes(input.waterSource)) errors.waterSource = 'Geçerli bir su türü seçin.';
  return { valid: Object.keys(errors).length === 0, errors };
}

function temperatureScore(value, assumptions) {
  return clamp(Math.abs(value - assumptions.temperatureReferenceC) / assumptions.temperatureToleranceC * 100);
}

function phScore(value, assumptions) {
  return clamp(Math.abs(value - assumptions.phReference) / assumptions.phTolerance * 100);
}

function microplasticsScore(value, assumptions) {
  if (value <= assumptions.microplasticReferencePerL) return clamp(value / assumptions.microplasticReferencePerL * 25);
  return clamp(25 + ((value - assumptions.microplasticReferencePerL) / (assumptions.microplasticUpperReferencePerL - assumptions.microplasticReferencePerL)) * 75);
}

function optionalScores(input) {
  const scores = {};
  if (input.turbidityNtu !== '' && input.turbidityNtu != null) scores.turbidity = clamp(Number(input.turbidityNtu) / 50 * 100);
  if (input.conductivityUs !== '' && input.conductivityUs != null) scores.conductivity = clamp(Math.abs(Number(input.conductivityUs) - 400) / 1000 * 100);
  if (input.dissolvedOxygenMgL !== '' && input.dissolvedOxygenMgL != null) scores.dissolvedOxygen = clamp((8 - Number(input.dissolvedOxygenMgL)) / 8 * 100);
  if (input.rainfallMm !== '' && input.rainfallMm != null) scores.rainfall = clamp(Number(input.rainfallMm) / 250 * 100);
  if (input.uvIndex !== '' && input.uvIndex != null) scores.uvIndex = clamp(Number(input.uvIndex) / 11 * 100);
  return scores;
}

function categoryFor(score, bands) {
  if (score <= bands.lowMax) return { key: 'low', label: 'Düşük ön değerlendirme' };
  if (score <= bands.mediumMax) return { key: 'medium', label: 'Orta ön değerlendirme' };
  return { key: 'high', label: 'Yüksek ön değerlendirme' };
}

export function calculateRisk(input, customAssumptions = {}) {
  const assumptions = { ...DEFAULT_ASSUMPTIONS, ...customAssumptions, weights: { ...DEFAULT_ASSUMPTIONS.weights, ...(customAssumptions.weights || {}) }, categoryBands: { ...DEFAULT_ASSUMPTIONS.categoryBands, ...(customAssumptions.categoryBands || {}) } };
  const validation = validateMeasurements(input);
  if (!validation.valid) throw new Error('Geçersiz ölçüm', { cause: validation.errors });
  const baseScores = {
    temperature: round(temperatureScore(Number(input.temperatureC), assumptions)),
    ph: round(phScore(Number(input.ph), assumptions)),
    microplastics: round(microplasticsScore(Number(input.microplasticsPerL), assumptions)),
    waterQuality: WATER_QUALITY_SCORES[input.waterQuality],
  };
  const optional = optionalScores(input);
  const baseWeightTotal = Object.values(assumptions.weights).reduce((sum, value) => sum + value, 0);
  const baseScore = Object.entries(baseScores).reduce((sum, [key, score]) => sum + score * (assumptions.weights[key] / baseWeightTotal), 0);
  const optionalValues = Object.values(optional);
  const optionalScore = optionalValues.length ? optionalValues.reduce((sum, value) => sum + value, 0) / optionalValues.length : null;
  const overallScore = optionalScore === null ? baseScore : baseScore * (1 - assumptions.optionalWeight) + optionalScore * assumptions.optionalWeight;
  const roundedOverall = round(clamp(overallScore));
  const category = categoryFor(roundedOverall, assumptions.categoryBands);
  const explanations = [
    `Sıcaklık sinyali ${baseScores.temperature}/100: ${input.temperatureC} °C, örnek ${assumptions.temperatureReferenceC} °C referansından ${round(Math.abs(Number(input.temperatureC) - assumptions.temperatureReferenceC))} °C uzaklıkta.`,
    `pH sinyali ${baseScores.ph}/100: ${input.ph}, örnek ${assumptions.phReference} referansından sapma gösteriyor.`,
    `Mikroplastik sinyali ${baseScores.microplastics}/100: ${input.microplasticsPerL} parçacık/L, örnek referans aralığıyla karşılaştırıldı.`,
    `Su kalitesi sinyali ${baseScores.waterQuality}/100: “${input.waterQuality === 'good' ? 'iyi' : input.waterQuality === 'moderate' ? 'orta' : 'zayıf'}” seçimi kullanıldı.`,
  ];
  explanations.push(`Su türü “${WATER_SOURCE_LABELS[input.waterSource]}” olarak kaydedildi; dokümandaki 7 su türü bağlamı korunur, ancak doğrulanmış bir su-türü katsayısı olmadığı için skoru tek başına değiştirmez.`);
  if (optionalScore !== null) explanations.push(`İsteğe bağlı ${optionalValues.length} ölçümün ortalama bağlamsal sinyali ${round(optionalScore)}/100; toplam skorun en fazla %${assumptions.optionalWeight * 100}’ini etkiledi.`);
  if (input.rainfallMm !== '' && input.rainfallMm != null) explanations.push(`Yağış değeri ${input.rainfallMm} mm olarak bağlamsal sinyale dahil edildi; tek başına iklim–mikroplastik korelasyonu hesaplanmadı.`);
  if (input.uvIndex !== '' && input.uvIndex != null) explanations.push(`UV indeksi ${input.uvIndex} olarak bağlamsal sinyale dahil edildi; mevsimsel parçalanma için doğrulanmış zaman serisi yok.`);
  return { score: roundedOverall, category, baseScores, optionalScores: optional, optionalScore: optionalScore === null ? null : round(optionalScore), explanations, assumptions, methodologyNote: 'Bu çıktı bilimsel tanı veya mevzuat uygunluğu değildir; örnek varsayımlarla üretilen açıklanabilir bir ön değerlendirmedir. Dokümandaki YOLOv8/SAHI modeli ve 3 yıllık iklim serisi bu depoya bağlı olmadığı için otomatik parçacık sayımı ve korelasyon/p-değeri üretilmez.' };
}

export function riskClass(key) { return `risk-${key}`; }
