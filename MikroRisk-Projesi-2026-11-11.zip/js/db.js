const DB_NAME = 'microrisk-db';
const DB_VERSION = 1;
const STORE = 'analyses';

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      const store = database.createObjectStore(STORE, { keyPath: 'id' });
      store.createIndex('createdAt', 'createdAt', { unique: false });
      store.createIndex('measuredAt', 'measuredAt', { unique: false });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function transaction(mode, operation) {
  return openDatabase().then((database) => new Promise((resolve, reject) => {
    const tx = database.transaction(STORE, mode);
    const store = tx.objectStore(STORE);
    let request;
    try { request = operation(store); } catch (error) { reject(error); return; }
    if (request) {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    }
    tx.oncomplete = () => database.close();
    tx.onerror = () => reject(tx.error);
  }));
}

export function saveAnalysis(record) { return transaction('readwrite', (store) => store.put(record)); }
export function getAnalysis(id) { return transaction('readonly', (store) => store.get(id)); }
export function getAnalyses() { return transaction('readonly', (store) => store.getAll()).then((records) => records.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))); }
export function deleteAnalysis(id) { return transaction('readwrite', (store) => store.delete(id)); }
