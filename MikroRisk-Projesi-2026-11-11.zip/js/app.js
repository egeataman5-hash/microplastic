import { calculateRisk, validateMeasurements, riskClass } from './risk-engine.js';
import { saveAnalysis, getAnalysis, getAnalyses } from './db.js';

const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];
const today = new Date().toISOString().slice(0, 10);
let analyses = [];
let toastTimer;

function formatDate(value) { return new Intl.DateTimeFormat('tr-TR', { dateStyle: 'medium' }).format(new Date(`${value}T12:00:00`)); }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char])); }
function qualityLabel(value) { return ({ good: 'İyi', moderate: 'Orta', poor: 'Zayıf' })[value] || '—'; }
function sourceLabel(value) { return ({ tap: 'İçme suyu (şebeke)', bottled: 'Şişe suyu', treated: 'Arıtılmış su', lake: 'Göl suyu (durgun)', rainwater: 'Yağmur suyu', river: 'Nehir suyu', wastewater: 'Atık su (arıtma öncesi)' })[value] || '—'; }
function seasonLabel(value) { return ({ spring: 'İlkbahar', summer: 'Yaz', autumn: 'Sonbahar', winter: 'Kış' })[value] || '—'; }
function showToast(message) { const toast = $('#toast'); toast.textContent = message; toast.classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('visible'), 3500); }

function setView(view) {
  $$('[data-panel]').forEach((panel) => panel.classList.toggle('hidden', panel.dataset.panel !== view));
  $$('.tab').forEach((tab) => tab.classList.toggle('is-active', tab.dataset.view === view));
  if (view === 'history') renderHistory();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function formInput() {
  const form = $('#analysis-form');
  const value = (name) => form.elements[name].value;
  const optional = (name) => value(name) === '' ? null : Number(value(name));
  return { sampleName: value('sampleName').trim(), measuredAt: value('measuredAt'), location: value('location').trim(), waterSource: value('waterSource'), temperatureC: value('temperatureC') === '' ? '' : Number(value('temperatureC')), ph: value('ph') === '' ? '' : Number(value('ph')), microplasticsPerL: value('microplasticsPerL') === '' ? '' : Number(value('microplasticsPerL')), waterQuality: value('waterQuality'), turbidityNtu: optional('turbidityNtu'), conductivityUs: optional('conductivityUs'), dissolvedOxygenMgL: optional('dissolvedOxygenMgL'), rainfallMm: optional('rainfallMm'), uvIndex: optional('uvIndex'), season: value('season'), isExample: form.elements.isExample.checked };
}

function showValidation(errors = {}) {
  $$('.field-error').forEach((element) => { element.textContent = ''; });
  $$('.field input,.field select').forEach((element) => element.classList.remove('invalid'));
  Object.entries(errors).forEach(([key, message]) => { const error = $(`[data-error-for="${key}"]`); const field = $(`[name="${key}"]`); if (error) error.textContent = message; if (field) field.classList.add('invalid'); });
}

function populateExample() {
  const values = { sampleName: 'Örnek kıyı istasyonu', measuredAt: today, location: 'Demo — kuzey kıyı', waterSource: 'river', temperatureC: '27.4', ph: '7.8', microplasticsPerL: '64', waterQuality: 'moderate', turbidityNtu: '18', conductivityUs: '690', dissolvedOxygenMgL: '5.6', rainfallMm: '12', uvIndex: '7.2', season: 'summer' };
  Object.entries(values).forEach(([name, value]) => { $(`[name="${name}"]`).value = value; });
  $('#is-example').checked = true;
  showValidation({});
  showToast('Örnek veri dolduruldu. Kaydı örnek olarak işaretledik.');
}

function renderSummary() { $('#history-count').textContent = analyses.length; }

function renderHistory() {
  const list = $('#history-list');
  const query = $('#history-search').value.trim().toLocaleLowerCase('tr-TR');
  const filtered = analyses.filter((record) => [record.sampleName, record.location, sourceLabel(record.measurements.waterSource), record.result.category.label].join(' ').toLocaleLowerCase('tr-TR').includes(query));
  $('#history-summary').textContent = `${filtered.length} kayıt gösteriliyor`;
  if (!filtered.length) { list.innerHTML = `<div class="empty-state"><div class="empty-visual">⌁</div><h3>${query ? 'Eşleşen kayıt bulunamadı' : 'Henüz kayıt yok'}</h3><p>${query ? 'Arama ifadesini değiştirin.' : 'İlk ölçümünüzü girerek açıklanabilir bir ön değerlendirme oluşturun.'}</p><button class="button button-primary" data-view="new-analysis">Yeni analiz başlat</button></div>`; return; }
  list.innerHTML = filtered.map((record) => `<article class="history-item"><div class="history-main"><div class="history-title">${escapeHtml(record.sampleName)} ${record.isExample ? '<span class="history-badge">ÖRNEK</span>' : ''}</div><div class="history-meta"><span>${escapeHtml(record.location)}</span><span>${formatDate(record.measuredAt)}</span></div></div><span class="risk-chip ${riskClass(record.result.category.key)}">${escapeHtml(record.result.category.label)}</span><span class="history-score">${record.result.score}/100</span><button class="text-button" data-detail-id="${record.id}">Ayrıntı →</button></article>`).join('');
}

function renderDetail(record) {
  $('#detail-example-badge').classList.toggle('hidden', !record.isExample);
  const factors = [['Sıcaklık', record.result.baseScores.temperature], ['pH', record.result.baseScores.ph], ['Mikroplastik yoğunluğu', record.result.baseScores.microplastics], ['Su kalitesi', record.result.baseScores.waterQuality]];
  const optional = Object.entries(record.result.optionalScores || {});
  const optionalNames = { turbidity: 'Bulanıklık', conductivity: 'İletkenlik', dissolvedOxygen: 'Çözünmüş oksijen', rainfall: 'Yağış', uvIndex: 'UV indeksi' };
  const optionalFactor = optional.length ? optional.map(([key, score]) => [optionalNames[key], score]) : [];
  const allFactors = [...factors, ...optionalFactor];
  $('#detail-content').innerHTML = `<div class="card detail-hero"><div><p class="eyebrow">${escapeHtml(record.measuredAt)} · ${escapeHtml(record.location)}</p><h2>${escapeHtml(record.sampleName)}</h2><p>${record.isExample ? 'Örnek / deneme verisi olarak işaretlendi.' : 'Kullanıcı tarafından girilmiş ölçüm kaydı.'}</p></div><div class="detail-score"><div class="score-ring" style="--score:${record.result.score * 3.6}deg"><div class="score-ring-inner"><strong>${record.result.score}</strong><small>/ 100</small></div></div><span class="risk-chip ${riskClass(record.result.category.key)}">${escapeHtml(record.result.category.label)}</span></div></div><div class="detail-grid"><div class="card factor-card"><h3 class="card-title">Faktör sinyalleri</h3>${allFactors.map(([label, score]) => `<div class="factor-row"><span class="factor-label">${label}</span><span class="factor-track"><span class="factor-fill" style="width:${score}%"></span></span><strong class="factor-value">${Math.round(score)}</strong></div>`).join('')}</div><div class="card measurement-card"><h3 class="card-title">Ölçüm özeti</h3><div class="measurement-grid"><div class="measurement-cell"><span>Su türü</span><strong>${sourceLabel(record.measurements.waterSource)}</strong></div><div class="measurement-cell"><span>Sıcaklık</span><strong>${record.measurements.temperatureC} °C</strong></div><div class="measurement-cell"><span>pH</span><strong>${record.measurements.ph}</strong></div><div class="measurement-cell"><span>Mikroplastik</span><strong>${record.measurements.microplasticsPerL}/L</strong></div><div class="measurement-cell"><span>Su kalitesi</span><strong>${qualityLabel(record.measurements.waterQuality)}</strong></div><div class="measurement-cell"><span>Yağış</span><strong>${record.measurements.rainfallMm ?? '—'} mm</strong></div><div class="measurement-cell"><span>UV / mevsim</span><strong>${record.measurements.uvIndex ?? '—'} · ${seasonLabel(record.measurements.season)}</strong></div><div class="measurement-cell"><span>Görsel kanıt</span><strong>${escapeHtml(record.measurements.imageName || 'Eklenmedi')}</strong></div></div></div></div><div class="card factor-card" style="margin-top:15px"><h3 class="card-title">Bu sonuç nasıl oluştu?</h3><ul class="explanation-list">${record.result.explanations.map((explanation) => `<li>${escapeHtml(explanation)}</li>`).join('')}</ul><div class="detail-note">${escapeHtml(record.result.methodologyNote)}</div></div>`;
  setView('detail');
}

async function handleSubmit(event) {
  event.preventDefault();
  const measurements = formInput();
  const validation = validateMeasurements(measurements);
  showValidation(validation.errors);
  if (!validation.valid) { showToast('Lütfen işaretli ölçümleri düzeltin.'); const first = $('.invalid'); first?.focus(); return; }
  const result = calculateRisk(measurements);
  const image = $('#image-input').files?.[0];
  measurements.imageName = image ? image.name : null;
  const record = { id: crypto.randomUUID(), createdAt: new Date().toISOString(), sampleName: measurements.sampleName, measuredAt: measurements.measuredAt, location: measurements.location, isExample: measurements.isExample, measurements, result };
  await saveAnalysis(record);
  analyses = await getAnalyses();
  renderSummary();
  renderDetail(record);
  showToast('Analiz kaydedildi.');
}

async function init() {
  $('#measured-at').value = today;
  $('#analysis-form').addEventListener('submit', handleSubmit);
  $('#load-example').addEventListener('click', populateExample);
  $('#image-input').addEventListener('change', (event) => { const file = event.target.files?.[0]; $('#image-file-name').textContent = file ? `${file.name} seçildi; yalnızca ilişkilendirme olarak saklanır.` : 'Görsel yalnızca dosya adıyla ilişkilendirilir; YOLOv8/SAHI modeli bağlı değil.'; });
  $('#history-search').addEventListener('input', renderHistory);
  document.addEventListener('click', async (event) => {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) { setView(viewButton.dataset.view); return; }
    const detailButton = event.target.closest('[data-detail-id]');
    if (detailButton) { const record = await getAnalysis(detailButton.dataset.detailId); if (record) renderDetail(record); }
  });
  try { analyses = await getAnalyses(); renderSummary(); } catch (error) { showToast('Yerel veritabanı açılamadı. Tarayıcı izinlerini kontrol edin.'); console.error(error); }
}

init();
