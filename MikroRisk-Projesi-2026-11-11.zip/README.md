# MikroRisk — Mikroplastik ve İklim Koşullarına Bağlı Çevresel Risk Ön Değerlendirmesi

MikroRisk, saha ölçümlerini tarayıcı içinde kalıcı olarak saklayan ve bu ölçümlere göre açıklanabilir bir **ön değerlendirme** üreten Türkçe bir web uygulamasıdır.

> Uyarı: Bu proje bilimsel olarak doğrulanmış bir mevzuat sınırı, sağlık/çevre tanısı veya yapay zekâ tahmini değildir. Risk bantları yalnızca yazılımın çalışmasını göstermek için kullanılan, düzenlenebilir örnek varsayımlardır. Gerçek kararlar için numune alma protokolü, laboratuvar doğrulaması, yerel mevzuat ve konu uzmanı değerlendirmesi gerekir.

## Mevcut özellikler

- Sıcaklık, pH, mikroplastik yoğunluğu ve su kalitesi girişi.
- Referans proje dokümanındaki 7 su türü: içme, şişe, arıtılmış, göl, yağmur, nehir ve atık su.
- İsteğe bağlı bulanıklık, iletkenlik ve çözünmüş oksijen alanları.
- İklim bağlamı için isteğe bağlı yağış, UV indeksi ve mevsim alanları.
- İsteğe bağlı mikroskop görüntüsü dosya adı ilişkilendirmesi; model bağlı değilken otomatik parçacık sayımı yapılmaz.
- Eksik, sayısal olmayan ve aralık dışı ölçümler için doğrulama.
- Modüler `js/risk-engine.js` risk hesaplama modülü.
- Düşük / orta / yüksek **ön değerlendirme** bantları ve faktör grafikleri.
- Açıklanabilir faktör katkıları ve varsayımlar paneli.
- Analiz sonuçlarını tarayıcı IndexedDB veritabanında kalıcı saklama.
- Geçmiş analizleri listeleme, arama ve ayrıntı görüntüleme.
- Gerçek veri ile örnek veriyi ayıran kayıt işareti.
- Tarayıcıdan çalıştırılabilen test sayfası.

## Gereksinimler

Uygulama herhangi bir derleme aracı veya paket yöneticisi gerektirmez. Güncel bir Chrome, Edge veya Firefox yeterlidir. IndexedDB için uygulamayı `file://` yerine bir HTTP sunucusu üzerinden açmak önerilir.

## Çalıştırma

### Seçenek 1 — Basit statik sunucu

Apache, IIS veya başka bir statik HTTP sunucusunun belge kökü olarak bu klasörü gösterin ve `index.html` adresini açın.

### Seçenek 2 — Python varsa

```text
python -m http.server 8080
```

Ardından `http://localhost:8080` adresini açın.

### Seçenek 3 — PHP varsa

```text
php -S 127.0.0.1:8787 -t .
```

Ardından `http://127.0.0.1:8787` adresini açın. Windows AppServ kurulumunda PHP yolu örneğin `C:\AppServ\php7\php.exe` olabilir.

### Seçenek 4 — Bu makinedeki Apache ile

Apache yapılandırmasında `DocumentRoot` olarak proje klasörünü gösterip 8787 gibi boş bir port seçin. Uygulama dosyaları statik olduğu için sunucu tarafı API gerekmez.

## Testleri çalıştırma

Tarayıcıda `tests/test-risk-engine.html` dosyasını açın. Sayfa, risk motorunun doğrulama, kategori, ağırlık ve açıklama davranışlarını çalıştırır ve başarılı/başarısız testleri gösterir.

Testler:

- Geçerli ölçüm kabulü.
- Eksik zorunlu alan reddi.
- pH ve mikroplastik aralık doğrulaması.
- Düşük, orta ve yüksek örnek kategori üretimi.
- İsteğe bağlı ölçümlerin etkisinin açıklanması.
- Sonuçta varsayım ve açıklama bulunması.

## Risk hesaplama yaklaşımı

`js/risk-engine.js`, dört ana sinyali örnek olarak ağırlıklandırır:

| Sinyal | Varsayılan ağırlık | Örnek yorum |
| --- | ---: | --- |
| Sıcaklık | %20 | 18 °C referansından uzaklık |
| pH | %20 | pH 7 referansından uzaklık |
| Mikroplastik yoğunluğu | %40 | 10 ve 100 parçacık/L örnek referansları |
| Su kalitesi | %20 | Kullanıcı seçimi: iyi / orta / zayıf |

İsteğe bağlı ölçümler girilirse toplam skorun en fazla %15'i kadar ek bağlamsal ağırlık uygulanır. Kategoriler 0–32 düşük, 33–65 orta, 66–100 yüksek olarak kodlanmıştır.

Bu sayılar herhangi bir ekosistem, tür, ülke veya mevzuat için geçerli eşik iddiası taşımaz. Uygulama her sonuçta “örnek varsayım” etiketini ve faktör açıklamasını gösterir. Üretim kullanımı öncesinde bu modül, doğrulanmış kaynaklar ve alan uzmanlarının onayıyla değiştirilmelidir.

## Referans proje dokümanıyla uyum ve sınırlar

`Climate_Responsive_AI_Microplastic_Analysis.pdf` görsel bir proje dokümanı olarak incelenmiştir. Dokümandaki YOLOv8 + SAHI küçük nesne tespiti, 7 su türü ve sıcaklık–yağış–UV/mevsim bağlamı uygulamanın veri modeline ve arayüzüne yansıtılmıştır. Ancak bu depoda YOLOv8 model ağırlıkları, SAHI çalışma kodu, Kaggle veri kümesi veya doğrulanmış 2022–2024 iklim zaman serisi bulunmamaktadır.

Bu nedenle uygulama görseli yalnızca ölçüm kaydına kanıt olarak ilişkilendirir; görselden otomatik mikroplastik sayısı üretmez. Tekil yağış/UV girdileri bağlamsal sinyal olarak gösterilebilir, fakat uygulama zaman serisi olmadan korelasyon, p-değeri veya kesin iklim etkisi iddiası üretmez. Su türü kaydedilir ve aranabilir; doğrulanmış bir su-türü katsayısı olmadığı için tek başına risk skorunu değiştirmez. Bu ayrım, proje dokümanındaki hedef mimari ile mevcut, doğrulanabilir uygulama kapsamını birbirinden ayırır.

## Veri saklama ve gizlilik

Kayıtlar sunucuya gönderilmez; tarayıcının yerel IndexedDB veritabanında tutulur. Tarayıcı verisi temizlenirse kayıtlar silinebilir. Üretim ortamında yetkilendirme, yedekleme, erişim kontrolü ve merkezi veritabanı ayrıca tasarlanmalıdır.

## Dosya yapısı

```text
index.html              Uygulama kabuğu
styles.css              Türkçe arayüz stilleri
js/app.js               Ekran akışı ve IndexedDB entegrasyonu
js/db.js                Kalıcı veri katmanı
js/risk-engine.js       Bağımsız, açıklanabilir risk hesaplayıcı
tests/test-risk-engine.html  Tarayıcı testleri
```
